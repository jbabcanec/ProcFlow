from math import sin, cos, pi, acos
from PyQt5.QtWidgets import (QApplication, QGraphicsView, QGraphicsScene, QGraphicsRectItem, QGraphicsLineItem,
                             QVBoxLayout, QPushButton, QWidget, QDockWidget, QListWidget, QMainWindow,
                             QGraphicsTextItem, QLabel, QTabWidget, QHBoxLayout, QTableWidget, QTableWidgetItem, QComboBox,
                             QMenu, QAction, QStyle, QTextEdit, QTreeWidget, QTreeWidgetItem)
from PyQt5.QtGui import QPen, QPolygonF, QFont, QPainterPath, QPainter, QFontMetrics
from PyQt5.QtCore import Qt, QPointF, QLineF, QSize, QRectF
from PyQt5.QtGui import QIcon, QTextCursor
from collections import defaultdict
import re

class MainWidget(QMainWindow):
    def __init__(self):
        super().__init__()

        self.node_counter = defaultdict(int)

        # Create the menu bar
        menuBar = self.menuBar()
        fileMenu = menuBar.addMenu("&File")
        viewMenu = menuBar.addMenu("&View")
        optionsMenu = menuBar.addMenu("&Options")
        helpMenu = menuBar.addMenu("&Help")

        fileMenu.addAction("&Open")
        fileMenu.addAction("&Save")
        fileMenu.addAction("&Import Metadata")
        fileMenu.addAction("&Modify Metadata")

        optionsMenu.addAction("&Scheduler")

        # Buttons
        self.validate_button = QPushButton('Validate')
        self.validate_button.setIcon(QIcon('check.ico'))  # Replace with the path to your validate icon
        self.validate_button.setIconSize(QSize(16, 16))  # Adjust icon size to your liking
        self.validate_button.clicked.connect(self.validate)

        self.run_button = QPushButton('Run')
        self.run_button.setIcon(QIcon('greenplay.ico'))  # Replace with the path to your run icon
        self.run_button.setIconSize(QSize(16, 16))  # Adjust icon size to your liking
        self.run_button.clicked.connect(self.run)

        # GraphWidget
        self.graphWidget = GraphWidget(self)

        # Camera snap button
        self.snap_button = QPushButton('Snap to Center')
        self.snap_button.clicked.connect(self.graphWidget.snap_to_center)

        # Zoom controls
        self.zoom_in_button = QPushButton('Zoom In')
        self.zoom_out_button = QPushButton('Zoom Out')
        self.zoom_level_dropdown = QComboBox()
        self.zoom_level_dropdown.addItems(['100%', '75%', '50%', 'Custom'])

        self.zoom_in_button.clicked.connect(self.zoom_in)
        self.zoom_out_button.clicked.connect(self.zoom_out)
        self.zoom_level_dropdown.currentTextChanged.connect(self.set_zoom_level)

        # Console
        self.consoleDock = QDockWidget("Console", self)
        self.console = Console(self)
        self.consoleDock.setWidget(self.console)
        self.addDockWidget(Qt.BottomDockWidgetArea, self.consoleDock)
        self.consoleDock.setFloating(False)
        self.consoleDock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetClosable)
        self.consoleDock.setAllowedAreas(Qt.BottomDockWidgetArea)
        self.consoleDock.setMinimumHeight(100)  # Set smaller default size
        self.consoleDock.setMaximumHeight(200)  # Set smaller maximum size
        self.console.append('>>> ')

        # Container widget for GraphWidget and buttons
        self.container_widget = QWidget()
        container_layout = QVBoxLayout(self.container_widget)

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.validate_button)
        button_layout.addWidget(self.run_button)
        button_layout.addWidget(self.zoom_in_button)
        button_layout.addWidget(self.zoom_out_button)
        button_layout.addWidget(self.zoom_level_dropdown)
        button_layout.addWidget(self.snap_button)
        button_layout.addStretch()
        button_layout.setContentsMargins(0, 0, 0, 0)  # Remove margins
        button_layout.setSpacing(0)  # Remove space between elements

        container_layout.addLayout(button_layout)
        container_layout.addWidget(self.graphWidget)

        # Set container widget as central widget
        self.setCentralWidget(self.container_widget)

        # Function Table
        self.function_table = QTableWidget()
        self.function_table.setColumnCount(3)
        self.function_table.setHorizontalHeaderLabels(['Function', 'In-Nodes', 'Out-Nodes'])
        function_data = [['generate_benes', '1', '1'], ['parse', '1', 'n'], ['compute_risk', '1', '1'], ['compare_files', 'n', '1'], ['BeneCompareFunc', '1', '1']]
        self.function_table.setRowCount(len(function_data))
        for i, row_data in enumerate(function_data):
            for j, data in enumerate(row_data):
                self.function_table.setItem(i, j, QTableWidgetItem(str(data)))

        # Utility Table
        self.input_table = QTableWidget()
        self.input_table.setColumnCount(3)
        self.input_table.setHorizontalHeaderLabels(['Utility', 'In-Nodes', 'Out-Nodes'])
        input_data = [['Start', '0', '1'], ['End', '1', '0'], ['Input File', '0', 'n'], ['Halt', '1', '1'], ['Resume', '1', '1']]
        self.input_table.setRowCount(len(input_data))
        for i, row_data in enumerate(input_data):
            for j, data in enumerate(row_data):
                self.input_table.setItem(i, j, QTableWidgetItem(str(data)))

        # Active Items
        self.activeItemsDock = QDockWidget("Active Items", self)
        self.activeItemsTree = QTreeWidget()
        self.activeItemsTree.setHeaderHidden(True)
        self.activeItemsDock.setWidget(self.activeItemsTree)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.activeItemsDock)
        self.activeItemsDock.setFloating(False)
        self.activeItemsDock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable | QDockWidget.DockWidgetClosable)
        self.activeItemsDock.setAllowedAreas(Qt.LeftDockWidgetArea)
        self.activeItemsDock.setMinimumWidth(200)  # Set smaller default size
        self.activeItemsDock.setMaximumWidth(400)  # Set smaller maximum size

        self.add_button = QPushButton('Add')
        self.add_button.clicked.connect(self.add_item)
        self.add_button.setFixedSize(100, 30)
        self.add_button.setEnabled(False)  # Disabled by default
        self.function_table.clicked.connect(lambda: self.add_button.setEnabled(True))  # Enable when a row is clicked
        self.input_table.clicked.connect(lambda: self.add_button.setEnabled(True))  # Enable when a row is clicked

        self.delete_button = QPushButton('Delete')
        self.delete_button.clicked.connect(self.delete_selected)
        self.delete_button.setFixedSize(100, 30)

        self.start_connection_button = QPushButton('Start Connection')
        self.start_connection_button.setCheckable(True)
        self.start_connection_button.toggled.connect(self.toggle_connection_mode)
        self.start_connection_button.setFixedSize(100, 30)

        self.dock = QDockWidget("Junction Palette", self)
        self.addDockWidget(Qt.RightDockWidgetArea, self.dock)

        self.tabWidget = QTabWidget(self.dock)

        self.functionTab = QWidget()
        self.inputsTab = QWidget()

        self.tabWidget.addTab(self.functionTab, "Functions")
        self.tabWidget.addTab(self.inputsTab, "Utilities")

        self.dock.setWidget(self.tabWidget)

        self.functionLayout = QVBoxLayout(self.functionTab)
        self.functionLayout.addWidget(self.function_table)

        self.inputsLayout = QVBoxLayout(self.inputsTab)
        self.inputsLayout.addWidget(self.input_table)

        self.buttonsDock = QDockWidget("Controls", self)
        self.buttonsDock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.addDockWidget(Qt.RightDockWidgetArea, self.buttonsDock)

        buttonsWidget = QWidget()
        buttonsLayout = QVBoxLayout()
        buttonsLayout.addWidget(self.add_button)
        buttonsLayout.addWidget(self.delete_button)
        buttonsLayout.addWidget(self.start_connection_button)
        buttonsWidget.setLayout(buttonsLayout)

        self.buttonsDock.setWidget(buttonsWidget)

    def showEvent(self, event):
        self.resize(1200, 800)

    def add_item(self):
        if self.tabWidget.currentIndex() == 0:  # Function tab
            selected_item = self.function_table.item(self.function_table.currentRow(), 0).text()
        else:  # Input tab
            selected_item = self.input_table.item(self.input_table.currentRow(), 0).text()
        self.node_counter[selected_item] += 1
        node_name = f'{selected_item}{self.node_counter[selected_item]}'
        self.graphWidget.add_node(selected_item, node_name)  # pass original name and node_name here

        # Add the node_name to the Active Items dock
        self.activeItemsTree.addTopLevelItem(QTreeWidgetItem([node_name]))

        self.add_button.setEnabled(False)

    def delete_selected(self):
        for item in self.graphWidget.scene().selectedItems():
            if isinstance(item, Node):
                # Remove item from active items tree
                for i in range(self.activeItemsTree.topLevelItemCount()):
                    if self.activeItemsTree.topLevelItem(i).text(0) == item.node_name:  # Use `node_name` instead
                        self.activeItemsTree.takeTopLevelItem(i)
                        break

                # Correctly remove the edges associated with the node
                for edge in item.edges:
                    # Remove edge from the other node
                    if edge.source_node is item:
                        edge.dest_node.edges.remove(edge)
                    else:
                        edge.source_node.edges.remove(edge)

                    # Remove edge from the scene
                    self.graphWidget.scene().removeItem(edge)

                # Remove item from the scene
                self.graphWidget.scene().removeItem(item)

    def toggle_connection_mode(self, checked):
        if checked:
            self.graphWidget.start_adding_edges()
        else:
            self.graphWidget.stop_adding_edges()

        # Update the tree
        self.update_tree()

    def zoom_in(self):
        self.graphWidget.scale(1.2, 1.2)

    def zoom_out(self):
        self.graphWidget.scale(1 / 1.2, 1 / 1.2)

    def set_zoom_level(self, level):
        if level == 'Custom':
            return
        scale = int(level[:-1]) / 100
        self.graphWidget.resetTransform()  # Reset zoom level to 100%
        self.graphWidget.scale(scale, scale)

    def validate(self):
        # Add the code to validate your setup here
        self.console.log("Validating...")  # Use the console to log messages
        # If validation is successful:
        self.console.log("Validation successful!")
        # If validation fails:
        self.console.log("Validation failed!")

    def run(self):
        # Add the code to run your setup here
        self.console.log("Running...")
        # If the run is successful:
        self.console.log("Run successful!")
        # If the run fails:
        self.console.log("Run failed!")

    def update_tree(self):
        self.activeItemsTree.clear()
        for item in self.graphWidget.scene().items():
            if isinstance(item, Node):
                node_name = item.node_name  # Use the `node_name` attribute instead of `text.toPlainText()`
                node_item = QTreeWidgetItem([node_name])
                self.activeItemsTree.addTopLevelItem(node_item)
                for edge in item.edges:
                    if edge.source_node is item:
                        connected_node_name = edge.dest_node.node_name  # Use the `node_name` attribute
                        connected_node_item = QTreeWidgetItem([f'From: {connected_node_name}'])
                        node_item.addChild(connected_node_item)
                    if edge.dest_node is item:
                        connected_node_name = edge.source_node.node_name  # Use the `node_name` attribute
                        connected_node_item = QTreeWidgetItem([f'To: {connected_node_name}'])
                        node_item.addChild(connected_node_item)


    #console functions

    def create_function(self, function_name):
        # Check if function exists in function table
        for row in range(self.function_table.rowCount()):
            if self.function_table.item(row, 0).text() == function_name:
                # Function exists, create it
                self.node_counter[function_name] += 1
                node_name = f'{function_name}{self.node_counter[function_name]}'
                self.graphWidget.add_node(function_name, node_name)  # pass original name and node_name here
                self.activeItemsTree.addTopLevelItem(QTreeWidgetItem([node_name]))  # Add item to active items tree
                self.console.log(f"Function '{function_name}' created.")
                return
        self.console.log(f"No function '{function_name}'.")

    def delete_function(self, function_name):
        # Check if function exists in scene
        items_to_delete = []
        for item in self.graphWidget.scene().items():
            if isinstance(item, Node) and item.node_name.startswith(function_name):  # Use `node_name` instead
                items_to_delete.append(item)

        for item in items_to_delete:
            # Correctly remove the edges associated with the node
            for edge in item.edges:
                # Remove edge from the other node
                if edge.source_node is item:
                    edge.dest_node.edges.remove(edge)
                else:
                    edge.source_node.edges.remove(edge)

                # Remove edge from the scene
                self.graphWidget.scene().removeItem(edge)

            # Remove item from the scene
            self.graphWidget.scene().removeItem(item)

            # Remove item from active items tree
            for i in range(self.activeItemsTree.topLevelItemCount()):
                if self.activeItemsTree.topLevelItem(i).text(0) == item.node_name:
                    self.activeItemsTree.takeTopLevelItem(i)
                    break

        if items_to_delete:
            self.console.log(f"Function '{function_name}' deleted.")
            self.update_tree()  # Update the tree
        else:
            self.console.log(f"No function '{function_name}'.")



    def connect_functions(self, source_name, dest_name):
        # Find the source and destination nodes
        source_node = None
        dest_node = None
        for item in self.graphWidget.scene().items():
            if isinstance(item, Node):
                if item.node_name.startswith(source_name):  # Use `node_name` instead
                    source_node = item
                elif item.node_name.startswith(dest_name):  # Use `node_name` instead
                    dest_node = item
        if source_node and dest_node:
            edge = Edge(source_node, dest_node)
            self.graphWidget.scene().addItem(edge)
            self.update_tree()  # Update the tree
            self.console.log(f"Connected '{source_name}' to '{dest_name}'.")
        else:
            if not source_node:
                self.console.log(f"No function '{source_name}'.")
            if not dest_node:
                self.console.log(f"No function '{dest_name}'.")

class Console(QTextEdit):
    def __init__(self, mainWidget):
        super().__init__()
        self.mainWidget = mainWidget
        self.setReadOnly(False)
        self.setStyleSheet("background-color: white; color: black;")  # Set dark background and white text

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Return:
            command = self.toPlainText().split('\n')[-1][4:]  # Strip the '>>> ' from the command
            self.process_command(command)
            self.append('>>> ')
        else:
            super().keyPressEvent(event)

    def process_command(self, command):
        if command.startswith('do ['):
            # Check if the closing brackets exist
            if ']:' not in command or command[-1] != '}':
                self.log('Invalid "do" loop syntax. Correct syntax is "do [num]: {command}".')
                return
            num_end_index = command.find(']')
            num_times = command[4:num_end_index]
            try:
                num_times = int(num_times)
                if num_times > 100:
                    self.log('Number of repetitions exceeds the limit of 100.')
                    return
            except ValueError:
                self.log('Invalid number of repetitions.')
                return

            sub_command = command[num_end_index+3:-1].strip()  # Extract the command within the brackets
            sub_command = sub_command[1:-1]  # Strip the '{' and '}' from the command
            for _ in range(num_times):
                self.process_command(sub_command)
        elif command.startswith('create('):
            function_name = command[7:]
            if function_name.endswith(')'):
                function_name = function_name[:-1]
            self.mainWidget.create_function(function_name)
        elif command.startswith('delete('):
            function_name = command[7:]
            if function_name.endswith(')'):
                function_name = function_name[:-1]
            self.mainWidget.delete_function(function_name)
        elif command.startswith('connect('):
            function_names = command[8:]
            if function_names.endswith(')'):
                function_names = function_names[:-1]
            function_names = function_names.split(' to ')
            if len(function_names) == 2:
                self.mainWidget.connect_functions(*function_names)
            else:
                self.log('Command not recognized: ' + command)
        elif command == 'clear':
            self.clear_log()
        else:
            self.log('Command not recognized: ' + command)


    def log(self, message):
        self.append(message)

    def clear_log(self):
        self.clear()

class Node(QGraphicsRectItem):
    def __init__(self, x, y, name, node_name):
        self.name = name  # Store the original name
        self.node_name = node_name  # Store the suffixed name
 
        # Change: Add Unicode symbol to the node text if it's a utility node
        unicode_dict = {
            'Start': '\u25B6',
            'End': '\u23F9',
            'Halt': '\u23F8',
            'Resume': '\u23E9',
            'Input File': '\U0001F4C1'
        }
        display_text = name
        if name in unicode_dict:
            display_text = f'{unicode_dict[name]} {name}'

        # Calculate text size
        font = QFont("Arial", 14)
        metrics = QFontMetrics(font)
        text_width = metrics.width(display_text)
        text_height = metrics.height()

        # Adjust box size to text
        w = text_width + 10  # Add some padding
        h = text_height + 10

        super().__init__(x, y, w, h)

        self.edges = []
        self.text = QGraphicsTextItem(display_text, self)  # Change: Use display_text instead of name
        self.text.setFont(font)
        self.text.setPos((w - text_width) / 2, (h - text_height) / 2)  # Center text
        self.setFlag(QGraphicsRectItem.ItemIsMovable)
        self.setFlag(QGraphicsRectItem.ItemSendsGeometryChanges)
        self.setFlag(QGraphicsRectItem.ItemIsSelectable)
        self.setBrush(Qt.white)
        self.setPen(QPen(Qt.black, 1))
        self.setZValue(-1)

    def itemChange(self, change, value):
        if change == QGraphicsRectItem.ItemPositionChange:
            for edge in self.edges:
                edge.adjust()
        return super().itemChange(change, value)

class Edge(QGraphicsLineItem):
    def __init__(self, source_node, dest_node):
        super().__init__()

        self.source_node = source_node
        self.dest_node = dest_node
        self.source_node.edges.append(self)
        self.dest_node.edges.append(self)

        self.setPen(QPen(Qt.black, 2))
        self.adjust()

        # Enable the itemIsSelectable flag to allow for double-click events
        self.setFlag(QGraphicsLineItem.ItemIsSelectable)

    def adjust(self):
        if not self.source_node or not self.dest_node:
            return
        line = QLineF(self.source_node.sceneBoundingRect().center(), 
                      self.dest_node.sceneBoundingRect().center())
        self.setLine(line)

    def paint(self, painter, option, widget=None):
        line = self.line()
        if line.length() == 0:
            return

        # Draw the line itself
        painter.setPen(QPen(Qt.black, 1, Qt.SolidLine))
        painter.drawLine(line)

        # Draw the arrow
        angle = acos(line.dx() / line.length())
        if line.dy() >= 0:
            angle = (pi * 2) - angle

        arrow_p1 = line.pointAt(0.5) + QPointF(sin(angle + pi / 3) * 10, cos(angle + pi / 3) * 10)
        arrow_p2 = line.pointAt(0.5) + QPointF(sin(angle + pi - pi / 3) * 10, cos(angle + pi - pi / 3) * 10);

        painter.setBrush(Qt.black)
        painter.drawPolygon(QPolygonF([line.pointAt(0.5), arrow_p1, arrow_p2]))

        # Highlight the line when selected
        if option.state & QStyle.State_Selected:
            highlight_line = line
            highlight_line.setLength(highlight_line.length() + 20)  # Extend the line length
            painter.setPen(QPen(Qt.black, 1, Qt.DashLine))
            painter.drawLine(highlight_line)

    def mouseDoubleClickEvent(self, event):
        # On double click, swap the source and destination nodes
        self.source_node, self.dest_node = self.dest_node, self.source_node
        self.adjust()

        # Update the active items tree
        self.scene().views()[0].mainWidget.update_tree()


    def contextMenuEvent(self, event):
        context_menu = QMenu()
        delete_action = QAction("Delete", context_menu)
        delete_action.triggered.connect(self.delete)
        context_menu.addAction(delete_action)

        change_direction_action = QAction("Change direction", context_menu)
        change_direction_action.triggered.connect(self.change_direction)
        context_menu.addAction(change_direction_action)

        context_menu.exec_(event.screenPos())

    def delete(self):
        self.source_node.edges.remove(self)
        self.dest_node.edges.remove(self)
        self.scene().removeItem(self)

    def change_direction(self):
        self.source_node, self.dest_node = self.dest_node, self.source_node
        self.adjust()

class GraphWidget(QGraphicsView):
    def __init__(self, mainWidget):
        super().__init__()

        self.setScene(QGraphicsScene(self))
        self.mainWidget = mainWidget
        self.start_node = None
        self.adding_edges = False
        self.last_node_position = QPointF(0, 0)
        self.setBackgroundBrush(Qt.lightGray)
        self.setRenderHint(QPainter.Antialiasing)

    def drawBackground(self, painter, rect):
        # Draw a dot grid on the scene's background
        left = int(rect.left())
        right = int(rect.right())
        top = int(rect.top())
        bottom = int(rect.bottom())

        first_left = left - (left % 20)
        first_top = top - (top % 20)

        # Draw vertical lines
        x = first_left
        while x < right:
            y = first_top
            while y < bottom:
                painter.drawPoint(x, y)
                y += 20
            x += 20

    def snap_to_center(self):
        # Calculate the bounding rectangle of all nodes
        nodes = [item for item in self.scene().items() if isinstance(item, Node)]
        if not nodes:
            return

        # Calculate bounding rectangle encompassing all nodes
        bounding_rect = QRectF(nodes[0].sceneBoundingRect())
        for node in nodes[1:]:
            bounding_rect = bounding_rect.united(node.sceneBoundingRect())

        # Adjust view to fit the bounding rectangle of all nodes, and center on it
        self.fitInView(bounding_rect, Qt.KeepAspectRatio)
        self.centerOn(bounding_rect.center())

    def add_node(self, name, node_name):
        node = Node(0, 0, name, node_name)
        node.setPos(self.last_node_position)
        self.last_node_position += QPointF(60, 60)
        self.scene().addItem(node)

    def delete_selected(self):
        for item in self.scene().selectedItems():
            if isinstance(item, Node):
                # Correctly remove the edges associated with the node
                for edge in item.edges:
                    # Remove edge from the other node
                    if edge.source_node is item:
                        edge.dest_node.edges.remove(edge)
                    else:
                        edge.source_node.edges.remove(edge)

                    # Remove edge from the scene
                    self.scene().removeItem(edge)

                # Remove item from the scene
                self.scene().removeItem(item)

    def mousePressEvent(self, event):
        if self.adding_edges:
            pos = self.mapToScene(event.pos())
            items = self.scene().items(pos)
            if items:
                item = items[0]
                if isinstance(item, Node) or isinstance(item.parentItem(), Node):
                    node = item if isinstance(item, Node) else item.parentItem()
                    if self.start_node is None:
                        self.start_node = node
                    elif node is not self.start_node:
                        edge = Edge(self.start_node, node)
                        self.scene().addItem(edge)
                        self.start_node = None
                        self.mainWidget.update_tree()  # Update the tree
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Delete:
            self.delete_selected()
        super().keyPressEvent(event)

    def start_adding_edges(self):
        self.adding_edges = True

    def stop_adding_edges(self):
        self.adding_edges = False
        self.start_node = None

app = QApplication([])
mainWidget = MainWidget()
mainWidget.resize(800, 600)  # Set the default size of the application window to be larger
mainWidget.show()
app.exec_()